package com.tma.dao;

import java.util.List;

import com.tma.entities.Manager;

public interface IManagerDAO {
	public void create(Manager manager);
	public void remove(Manager manager);
	public void edit(Manager manager);
    public List<Manager> findAll();
    public Manager find(int id);
}
