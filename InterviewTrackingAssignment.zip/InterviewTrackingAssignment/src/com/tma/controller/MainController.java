package com.tma.controller;

import org.springframework.stereotype.Controller;

@Controller

public class MainController {

}
