package com.tma.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tma.dao.IManagerDAO;
import com.tma.entities.Manager;
import com.tma.service.IManagerService;

@Service
@Transactional
public class ManagerServiceImpl implements IManagerService {
	
	@Autowired
	private IManagerDAO managerDAO;
	
	@Override
	public void create(Manager manager) {
		// TODO Auto-generated method stub
		managerDAO.create(manager);
	}

	@Override
	public void remove(Manager manager) {
		// TODO Auto-generated method stub
		managerDAO.remove(manager);
	}

	@Override
	public void edit(Manager manager) {
		// TODO Auto-generated method stub
		managerDAO.edit(manager);
	}

	@Override
	public List<Manager> findAll() {
		// TODO Auto-generated method stub
		return managerDAO.findAll();
	}

	@Override
	public Manager find(int id) {
		// TODO Auto-generated method stub
		return managerDAO.find(id);
	}

}
