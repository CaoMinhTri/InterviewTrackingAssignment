package com.tma.service;

import java.util.List;

import com.tma.entities.Role;

public interface RoleService {
	public List<Role> findAll();
}
