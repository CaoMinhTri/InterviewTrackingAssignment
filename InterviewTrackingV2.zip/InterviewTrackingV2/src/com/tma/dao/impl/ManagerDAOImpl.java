package com.tma.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tma.dao.ManagerDAO;
import com.tma.entities.Manager;

@Repository
public class ManagerDAOImpl implements ManagerDAO {

	@Autowired(required = true)
	private SessionFactory sessionFactory;

	@Override
	public void create(Manager manager) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().persist(manager);
	}

	@Override
	public void remove(Manager manager) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().delete(manager);
	}

	@Override
	public void edit(Manager manager) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(manager);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Manager> findAll() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createCriteria(Manager.class).list();
	}

	@Override
	public Manager find(int id) {
		// TODO Auto-generated method stub
		return (Manager) sessionFactory.getCurrentSession().get(Manager.class, id);
	}

}
