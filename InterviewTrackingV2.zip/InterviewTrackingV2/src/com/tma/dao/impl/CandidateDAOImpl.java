package com.tma.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tma.dao.CandiddateDAO;
import com.tma.entities.Candidate;

@Repository
public class CandidateDAOImpl implements CandiddateDAO {

	@Autowired(required = true)
	private SessionFactory sessionFactory;

	@Override
	public void create(Candidate candidate) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().persist(candidate);
	}

	@Override
	public void remove(Candidate candidate) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().delete(candidate);
	}

	@Override
	public void edit(Candidate candidate) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(candidate);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Candidate> findAll() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createCriteria(Candidate.class).list();
	}

	@Override
	public Candidate find(int id) {
		// TODO Auto-generated method stub
		return (Candidate) sessionFactory.getCurrentSession().get(Candidate.class, id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Candidate> findByInterviewID(int id) {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createCriteria(Candidate.class)
				.add(Restrictions.eq("InterviewID", id)).list();

	}

}
