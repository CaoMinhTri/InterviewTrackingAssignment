package com.tma.dao;

import java.util.List;

import com.tma.entities.Candidate;

public interface CandiddateDAO {
	public void create(Candidate candidate);
	public void remove(Candidate candidate);
	public void edit(Candidate candidate);
    public List<Candidate> findAll();
    public List<Candidate> findByInterviewID(int id);
    public Candidate find(int id);
   
}
