package com.tma.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tma.entities.Manager;
import com.tma.service.ManagerService;

@Controller
@RequestMapping(value = "/manager")
public class ManagerController {
	@Autowired(required=true)
	private ManagerService managerService;
	
	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.addAttribute("listManager", managerService.findAll());
		return "listManager";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.addAttribute("manager", new Manager());
		return "addManager";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "manager") Manager manager) {
		managerService.create(manager);
		return "redirect:/manager.html";
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") int id) {
		managerService.remove(managerService.find(id));
		return "redirect:/manager.html";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.addAttribute("manager", managerService.find(id));
		return "editManager";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "candidate") Manager manager) {
		managerService.edit(manager);
		return "redirect:/interview.html";
	}
}
