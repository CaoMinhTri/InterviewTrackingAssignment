package com.tma.controller;

import java.util.List;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.tma.entities.Manager;
import com.tma.entities.Role;
import com.tma.service.ManagerService;
import com.tma.service.RoleService;
import com.tma.validator.ManagerValidator;

@Controller
@RequestMapping(value = "/manager**")
public class ManagerController {

	@Autowired(required = true)
	private ManagerService managerService;

	@Autowired(required = true)
	private RoleService roleService;

	// @Autowired
	// private ManagerValidator managerValidator;

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.addAttribute("listManager", managerService.findAll());
		return "listManager";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.addAttribute("manager", new Manager());
		modelMap.addAttribute("listRole", roleService.findAll());
		return "addManager";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "manager") @Valid Manager manager, BindingResult bindingResult) {
		ManagerValidator managerValidator = new ManagerValidator();
		managerValidator.validate(manager, bindingResult);
		if (bindingResult.hasErrors()) {
			return "addManager";
		} else {
			managerService.create(manager);
			return "redirect:/manager.html";
		}
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") int id) {
		managerService.remove(managerService.find(id));
		return "redirect:/manager.html";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.addAttribute("manager", managerService.find(id));
		modelMap.addAttribute("listRole", roleService.findAll());
		return "editManager";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "manager") @Valid Manager manager, BindingResult bindingResult) {
		ManagerValidator managerValidator = new ManagerValidator();
		managerValidator.validate(manager, bindingResult);
		if (bindingResult.hasErrors()) {
			int id = manager.getId();
			return "redirect:/manager/edit/" + id + ".html";
		} else {
			managerService.edit(manager);
			return "redirect:/manager.html";
		}
	}
}
