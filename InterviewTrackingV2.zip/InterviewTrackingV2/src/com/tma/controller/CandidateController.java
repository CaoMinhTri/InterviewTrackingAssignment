package com.tma.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tma.entities.Candidate;
import com.tma.entities.Manager;
import com.tma.service.CandidateService;
import com.tma.service.ManagerService;
import com.tma.validator.CandidateValidator;

@Controller
@RequestMapping(value = "/candidate**")
public class CandidateController {

	@Autowired(required = true)
	private CandidateService candidateService;
	
	@Autowired(required = true)
	private ManagerService managerService;

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.addAttribute("listCandidate", candidateService.findAll());
		return "listCandidate";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.addAttribute("candidate", new Candidate());
		return "addCandidate";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "candidate") @Valid Candidate candidate, BindingResult bindingResult) {
		CandidateValidator candidateValidator = new CandidateValidator();
		candidateValidator.validate(candidate, bindingResult);
		if (bindingResult.hasErrors()) {
			return "addCandidate";
		} else {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//			UserDetails userDetails = (UserDetails) authentication.getPrincipal();
			String username = authentication.getName();
			Manager manager = managerService.findByUsername(username);
			candidate.setManager(manager);
			candidateService.create(candidate);
			return "redirect:/candidate.html";
		}
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") int id) {
		candidateService.remove(candidateService.find(id));
		return "redirect:/candidate.html";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.addAttribute("candidate", candidateService.find(id));
		return "editCandidate";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "candidate") @Valid Candidate candidate, BindingResult bindingResult) {
		CandidateValidator candidateValidator = new CandidateValidator();
		candidateValidator.validate(candidate, bindingResult);
		if (bindingResult.hasErrors()) {
			int id = candidate.getId();
			return "editCandidate";
		} else {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			String username = authentication.getName();
			Manager manager = managerService.findByUsername(username);
			candidate.setManager(manager);
			candidateService.edit(candidate);
			return "redirect:/candidate.html";
		}
	}

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}
}
